#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct timespec timespec_t;

double get_elapsed_time_sec(const timespec_t *start, const timespec_t *end) {
    long start_nanos = (long)1e9 * start->tv_sec + start->tv_nsec;
    long end_nanos = (long)1e9 * end->tv_sec + end->tv_nsec;
    return (double)(end_nanos - start_nanos) / 1e9;
}

// Matrix operation A = A + B
// You can think of int **A as equivalent to int[][] A
void addMatrices1(int** A, int** B, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            A[i][j] = A[i][j] + B[i][j];
        }
    }
}

// Matrix operation A = A + B
// You can think of int **A as similar to int[][] A
void addMatrices2(int **A, int **B, int n) {
    for (int j = 0; j < n; j++) {
        for (int i = 0; i < n; i++) {
            A[i][j] = A[i][j] + B[i][j];
        }
    }
}

// Fill an n by n matrix with random integers
int** generateMatrix(int n) {
    int **M = malloc(n * sizeof(int*));
    if (M == NULL) {
        fprintf(stderr, "Failed to allocate space for matrix\n");
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < n; i++) {
        M[i] = malloc(n * sizeof(int));
        if (M[i] == NULL) {
            fprintf(stderr, "Failed to allocate space for matrix row %d\n", i);
            exit(EXIT_FAILURE);
        }

        for (int j = 0; j < n; j++) {
            M[i][j] = rand();
        }
    }
    return M;
}

void freeMatrix(int **M, int n) {
    for (int i = 0; i < n; i++) {
        free(M[i]);
    }
    free(M);
}

int main(int argc, char **argv) {
    if (argc != 3) {
        printf("Usage: %s <rows|cols> <size>\n", argv[0]);
        return 1;
    }
    int matrix_size = atoi(argv[2]);

    int **A = generateMatrix(matrix_size);
    int **B = generateMatrix(matrix_size);

    if (strcmp(argv[1], "rows") == 0) {
        addMatrices1(A, B, matrix_size);
    } else {
        addMatrices2(A, B, matrix_size);
    }

    freeMatrix(A, matrix_size);
    freeMatrix(B, matrix_size);
    return EXIT_SUCCESS;
}
