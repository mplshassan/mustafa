#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

typedef struct timespec timespec_t;

double get_elapsed_time_sec(const timespec_t *start, const timespec_t *end) {
    unsigned long start_nanos = (long)1e9 * start->tv_sec + start->tv_nsec;
    unsigned long end_nanos = (long)1e9 * end->tv_sec + end->tv_nsec;
    return (double)(end_nanos - start_nanos) / 1e9;
}

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s <nap_length>\n", argv[0]);
        return 0;
    }

    timespec_t start_wall;
    timespec_t start_cpu;
    timespec_t end_wall;
    timespec_t end_cpu;

    int nap_length = atoi(argv[1]);
    printf("Napping for %d seconds...\n", nap_length);
    clock_gettime(CLOCK_REALTIME, &start_wall);
    clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &start_cpu);
    sleep(nap_length);
    clock_gettime(CLOCK_REALTIME, &end_wall);
    clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &end_cpu);
    printf("All done!\n");

    printf("Wall time elapsed: %.3f\n", get_elapsed_time_sec(&start_wall, &end_wall));
    printf("CPU time elapsed: %.3f\n", get_elapsed_time_sec(&start_cpu, &end_cpu));

    return 0;
}
