#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>

#define BUF_SIZE 4096

// Program to count the number of occurrences of a particular
// character in a body of text.
// Reads things in up to BUF_SIZE characters (bytes) at a time
int main(int argc, char **argv) {
    if (argc < 3) {
        printf("Usage: %s <text_file> <character>\n", argv[0]);
        return 0;
    }
    const char *file_name = argv[1];
    char search_char = argv[2][0];

    int fd = open(file_name, O_RDONLY);
    if (fd == -1) {
        perror("open");
        return 1;
    }

    unsigned char_count = 0;
    char buf[BUF_SIZE];
    int bytes_read;

    // TODO Read up to BUF_SIZE characters into 'buf'
    // Count occurrences of 'search_char' in 'buf'
    // Update 'char_count' accordingly
    // Then repeat by reading next chunk into 'buf'

    while ((bytes_read = read(fd, buf, BUF_SIZE)) > 0) {
        for (int i = 0; i < bytes_read; i++) {
            if (buf[i] == search_char) {
                char_count++;
            }
        }
    }


    if (close(fd) == -1) {
        perror("close");
        return 1;
    }

    printf("Found %d occurrences of character '%c'\n", char_count, search_char);
    return 0;
}
