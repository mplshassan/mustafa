#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>

// Program to count the number of occurrences of a particular 
// character in a body of text.
// Reads things in just one character (one byte) at a time
int main(int argc, char **argv) {
    if (argc < 3) {
        printf("Usage: %s <text_file> <character>\n", argv[0]);
        return 0;
    }
    const char *file_name = argv[1];
    char search_char = argv[2][0];

    int fd = open(file_name, O_RDONLY);
    if (fd == -1) {
        perror("open");
        return 1;
    }

    unsigned char_count = 0;
    char c;
    int bytes_read;
    while ((bytes_read = read(fd, &c, sizeof(char))) > 0) {
        if (c == search_char) {
            char_count++;
        }
    }
    if (bytes_read == -1) {
        perror("read");
        close(fd);
        return 1;
    }
    if (close(fd) == -1) {
        perror("close");
        return 1;
    }

    printf("Found %d occurrences of character '%c'\n", char_count, search_char);
    return 0;
}
